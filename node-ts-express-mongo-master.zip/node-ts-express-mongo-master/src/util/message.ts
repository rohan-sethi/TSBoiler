
export const Messages: any = {
    ERROR_401:"Unauthorized access",
    ERROR_500:"Internal server error",
    ERROR_422:"User already exists",
    USER_CREATED: "User created successfully",
    ERROR_404: "No record found",
    SIGNIN: "Signed in successfully",
    EMAIL_SENT: "Email has been sent successfully.",
    PASSWORD_RESET: "Password has been rest successfully"

}