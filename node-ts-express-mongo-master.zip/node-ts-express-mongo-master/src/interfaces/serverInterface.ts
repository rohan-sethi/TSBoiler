import * as express from 'express';

export interface IServer {
    app: express.Application;
}
